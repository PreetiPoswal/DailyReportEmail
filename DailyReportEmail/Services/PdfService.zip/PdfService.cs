﻿using DailyReportEmail.Interfaces;
using DailyReportEmail.Models;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace DailyReportEmail.Services
{
    public class PdfService : IPdfService
    {
        private readonly IWebHostEnvironment _webHostEnvironment;

        public PdfService(IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;

            // Initializing Community License natively
            QuestPDF.Settings.License = LicenseType.Community;
        }

        public byte[] GenerateDailyReport(DailyReportModel model)
        {
            var logoPath = ResolveLogoPath();
            var reportDateText = model.ReportDate.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
            var reportTimeText = DateTime.Now.ToString("hh:mm tt", CultureInfo.InvariantCulture);
            var currencyCulture = CultureInfo.GetCultureInfo("en-IN");
            var onlineCollectionIconPath = ResolveAssetPath("summary-icons", "online-collection.png");
            var overallRevenueIconPath = ResolveAssetPath("summary-icons", "overall-revenue.png");
            var totalPatientsIconPath = ResolveAssetPath("summary-icons", "total-patients.png");

            // Added .GeneratePdf() at the very end of the Document block to resolve byte[] implicit conversion error.
            return Document.Create(container =>
            {
                // =====================================================================
                // PAGE 1: TOOTHTECH CENTER PERFORMANCE OVERVIEW & FLAG 1 METRICS
                // =====================================================================
                container.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(20);
                    page.DefaultTextStyle(x => x.FontSize(9).FontColor(Colors.Black).FontFamily("Helvetica"));

                    page.Header().PaddingBottom(10).Column(column =>
                    {
                        column.Item().Row(row =>
                        {
                            row.ConstantItem(90).Column(col =>
                            {
                                if (File.Exists(logoPath))
                                    col.Item().Height(42).AlignCenter().Image(logoPath).FitArea();

                                col.Item().PaddingTop(1).AlignCenter().Text("CSSH IT").Bold().FontSize(8).FontColor("#475569");
                            });

                            row.RelativeItem().PaddingHorizontal(12).AlignCenter().Column(col =>
                            {
                                col.Item().AlignCenter().Text("Smile Sync").Bold().FontSize(23).FontColor("#374151");
                                col.Item().AlignCenter().Text("DAILY INSIGHT").Bold().FontSize(13).FontColor("#475569");
                                col.Item().PaddingTop(3).Row(divider =>
                                {
                                    divider.RelativeItem().PaddingTop(4).LineHorizontal(0.8f).LineColor("#475569");
                                    divider.ConstantItem(18).AlignCenter().Text("◆").FontSize(7).FontColor("#475569");
                                    divider.RelativeItem().PaddingTop(4).LineHorizontal(0.8f).LineColor("#475569");
                                });
                                col.Item().PaddingTop(3).AlignCenter().Text($"This report shows today's analytics at Smile Sync of  {reportDateText} {reportTimeText}.").FontSize(10).FontColor(Colors.Grey.Darken2);
                            });

                            row.ConstantItem(80).AlignMiddle().Border(0.7f).BorderColor("#cbd5e1").Padding(4).Column(col =>
                            {
                                col.Item().Text("Report Generation").FontSize(6).FontColor(Colors.Grey.Darken1);
                                col.Item().Text(reportDateText).Bold().FontSize(8).FontColor("#374151");
                                col.Item().Text(reportTimeText).FontSize(7).FontColor("#374151");
                            });
                        });
                        column.Item().PaddingTop(3).LineHorizontal(1.2f).LineColor("#475569");
                    });

                    page.Content().Column(column =>
                    {
                        column.Spacing(12);
                        column.Item().Row(row =>
                        {
                            row.Spacing(7);
                            row.RelativeItem().Border(0.7f).BorderColor("#bbf7d0").Background("#f0fdf4").Padding(8).Column(c => CreateSummaryCard(c, "CASH COLLECTION", FormatCurrency(model.ToothTech_TotalCashPaid, currencyCulture), "Counter cash collection", "₹", "#15803d", "#dcfce7"));
                            row.RelativeItem().Border(0.7f).BorderColor("#bae6fd").Background("#f0f9ff").Padding(8).Column(c => CreateSummaryCard(c, "ONLINE COLLECTION", FormatCurrency(model.ToothTech_TotalOnlinePaid, currencyCulture), "Gateway paid amount", "", "#0369a1", "#e0f2fe", onlineCollectionIconPath));
                            row.RelativeItem().Border(0.7f).BorderColor("#ddd6fe").Background("#f5f3ff").Padding(8).Column(c => CreateOverallRevenueCard(c, model.TodaysRevenue, model.TodaysCollection, currencyCulture, overallRevenueIconPath));
                            row.RelativeItem().Border(0.7f).BorderColor("#fed7aa").Background("#fff7ed").Padding(8).Column(c => CreateSummaryCard(c, "TOTAL PATIENTS", $"{model.ToothTech_TotalFootfall}", $"New: {model.ToothTech_NewPatients} | Old: {model.ToothTech_OldPatients}", "", "#c2410c", "#ffedd5", totalPatientsIconPath));
                        });

                        // --- FLAG 1 Table: Clinical Department Breakdown ---
                        column.Item().PaddingTop(4).Background("#475569").PaddingVertical(6).AlignCenter().Text("DEPARTMENT-WISE PERFORMANCE SUMMARY").Bold().FontSize(11).FontColor(Colors.White);
                        column.Item().Table(table =>
                        {
                            table.ColumnsDefinition(columns =>
                            {
                                columns.ConstantColumn(25);   // SNo
                                columns.RelativeColumn(2.0f); // Department Name
                                columns.RelativeColumn(1.0f); // Cash
                                columns.RelativeColumn(1.0f); // Online
                                columns.RelativeColumn(0.7f); // New Pat
                                columns.RelativeColumn(0.7f); // Revisit
                                columns.RelativeColumn(1.1f); // Revenue Created
                                columns.RelativeColumn(1.1f); // Revenue Coll
                                columns.RelativeColumn(0.9f); // Prescribed
                                columns.RelativeColumn(1.0f); // Performed
                            });

                            table.Header(header =>
                            {
                                header.Cell().RowSpan(2).Background("#f1f5f9").Border(0.5f).BorderColor("#d1d5db").Padding(4).AlignCenter().AlignMiddle().Text("#").Bold().FontColor("#374151").FontSize(8);
                                header.Cell().RowSpan(2).Background("#f1f5f9").Border(0.5f).BorderColor("#d1d5db").Padding(4).AlignLeft().AlignMiddle().Text("Department").Bold().FontColor("#374151").FontSize(8);
                                header.Cell().ColumnSpan(2).Background("#f1f5f9").Border(0.5f).BorderColor("#d1d5db").Padding(4).AlignCenter().Text("Total Collection").Bold().FontColor("#374151").FontSize(8);
                                header.Cell().ColumnSpan(2).Background("#f1f5f9").Border(0.5f).BorderColor("#d1d5db").Padding(4).AlignCenter().Text("Patient").Bold().FontColor("#374151").FontSize(8);
                                header.Cell().ColumnSpan(2).Background("#f1f5f9").Border(0.5f).BorderColor("#d1d5db").Padding(4).AlignCenter().Text("Revenue").Bold().FontColor("#374151").FontSize(8);
                                header.Cell().ColumnSpan(2).Background("#f1f5f9").Border(0.5f).BorderColor("#d1d5db").Padding(4).AlignCenter().Text("Test").Bold().FontColor("#374151").FontSize(8);

                                foreach (var subHeader in new[] { "Cash", "Online", "New", "Revisit", "Created", "Collected", "Prescribed", "Performed" })
                                    header.Cell().Background("#f8fafc").Border(0.5f).BorderColor("#d1d5db").Padding(4).AlignCenter().Text(subHeader).Bold().FontColor("#374151").FontSize(7);
                            });

                            if (model.Departments != null && model.Departments.Any())
                            {
                                foreach (var dept in model.Departments)
                                {
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(4).AlignLeft().Text(dept.SNo.ToString()).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(4).AlignLeft().Text(dept.DepartmentName ?? "-").FontSize(8).Bold();
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(4).AlignRight().Text(FormatCurrency(dept.CollectionCash, currencyCulture)).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(4).AlignRight().Text(FormatCurrency(dept.CollectionOnline, currencyCulture)).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(4).AlignRight().Text(dept.PatientNew.ToString("N0")).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(4).AlignRight().Text(dept.PatientReVisit.ToString("N0")).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(4).AlignRight().Text(FormatCurrency(dept.RevenueCreated, currencyCulture)).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(4).AlignRight().Text(FormatCurrency(dept.RevenueCollected, currencyCulture)).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(4).AlignCenter().Text(dept.PrescribedPerformed ?? "-").FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(4).AlignCenter().Text("-").FontSize(8);
                                }
                            }
                            else
                            {
                                table.Cell().ColumnSpan(10).Border(0.5f).BorderColor("#e9eff8").Padding(10).AlignCenter().Text("No Department Records Available Today").FontColor(Colors.Grey.Darken2).Italic();
                            }
                        });
                    });

                    page.Footer().Row(row =>
                    {
                        row.RelativeItem().PaddingTop(4).LineHorizontal(0.5f).LineColor("#cbd5e1");
                        row.ConstantItem(160).AlignCenter().Text("Smile Sync Daily Insight • System Generated Report").FontColor(Colors.Grey.Darken1).FontSize(8);
                        row.RelativeItem().PaddingTop(4).LineHorizontal(0.5f).LineColor("#cbd5e1");
                    });
                });

                // =====================================================================
                // PAGE 2: HMPK SUPPLY CHAIN & PROCUREMENT SUMMARY
                // =====================================================================
                container.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(20);
                    page.DefaultTextStyle(x => x.FontSize(9).FontColor(Colors.Black).FontFamily("Helvetica"));

                    page.Header().Column(column =>
                    {
                        column.Item().PaddingBottom(6).Row(row =>
                        {
                            row.ConstantItem(90).AlignMiddle().Column(col =>
                            {
                                if (File.Exists(logoPath))
                                    col.Item().Height(42).AlignCenter().Image(logoPath).FitArea();

                                col.Item().PaddingTop(1).AlignCenter().Text("CSSH IT").Bold().FontSize(8).FontColor("#475569");
                            });

                            row.RelativeItem().PaddingHorizontal(12).AlignCenter().AlignMiddle().Column(col =>
                            {
                                col.Item().AlignCenter().Text("HMPK").Bold().FontSize(23).FontColor("#374151");
                                col.Item().AlignCenter().Text("DAILY INSIGHT").Bold().FontSize(13).FontColor("#475569");
                                col.Item().PaddingTop(3).Row(divider =>
                                {
                                    divider.RelativeItem().PaddingTop(4).LineHorizontal(0.8f).LineColor("#475569");
                                    divider.ConstantItem(18).AlignCenter().Text("◆").FontSize(7).FontColor("#475569");
                                    divider.RelativeItem().PaddingTop(4).LineHorizontal(0.8f).LineColor("#475569");
                                });
                                col.Item().PaddingTop(3).AlignCenter().Text($"This report shows today's analytics at HMPK as of {reportDateText} {reportTimeText}.").FontSize(10).FontColor(Colors.Grey.Darken2);
                            });

                            row.ConstantItem(80).AlignMiddle().Border(0.7f).BorderColor("#cbd5e1").Padding(4).Column(col =>
                            {
                                col.Item().Text("Report Generation").FontSize(6).FontColor(Colors.Grey.Darken1);
                                col.Item().Text(reportDateText).Bold().FontSize(8).FontColor("#374151");
                                col.Item().Text(reportTimeText).FontSize(7).FontColor("#374151");
                            });
                        });
                        column.Item().PaddingTop(3).LineHorizontal(1.2f).LineColor("#475569");
                    });

                    page.Content().Column(column =>
                    {
                        column.Spacing(12);
                        column.Item().Row(row =>
                        {
                            row.Spacing(7);
                            row.RelativeItem().Border(0.6f).BorderColor("#d1d5db").Padding(8).Column(c => CreateSummaryCard(c, "TOTAL DEMANDS",    $"{model.TodayDemand}",                             $"Pending: {model.PendingDemand} | Approved: {model.ApprovedDemand} | Rejected: {model.RejectedDemand}",         "", "#374151"));
                            row.RelativeItem().Border(0.6f).BorderColor("#d1d5db").Padding(8).Column(c => CreateSummaryCard(c, "TOTAL PO AMOUNT",  FormatCurrency(model.TotalPOAmount, currencyCulture),   $"Total POs: {model.TodayPO} | Pending: {model.PendingPO} | Rejected: {model.RejectedPO}",                      "", "#374151"));
                            row.RelativeItem().Border(0.6f).BorderColor("#d1d5db").Padding(8).Column(c => CreateSummaryCard(c, "TOTAL DMR AMOUNT", FormatCurrency(model.TotalDMRAmount, currencyCulture),  $"Total DMR: {model.TodayDMR} | Pending: {model.PendingDMR} | Rejected: {model.RejectedDMR}",                   "", "#374151"));
                            row.RelativeItem().Border(0.6f).BorderColor("#d1d5db").Padding(8).Column(c => CreateSummaryCard(c, "TOTAL BILL AMOUNT", FormatCurrency(model.TotalBillAmount, currencyCulture), $"Payments: {model.TodayBillPayment} | Pending: {model.PendingBillPayment} | Approved: {model.ApprovedBillPayment} | Rejected: {model.RejectedBillPayment}", "", "#374151"));
                        });

                        column.Item().PaddingTop(4).Background("#475569").PaddingVertical(6).AlignCenter().Text("DETAILED SUMMARY").Bold().FontSize(11).FontColor(Colors.White);
                        column.Item().Table(table =>
                        {
                            table.ColumnsDefinition(columns =>
                            {
                                columns.RelativeColumn(2.1f); // Description
                                columns.RelativeColumn(0.8f); // Total
                                columns.RelativeColumn(0.8f); // Pending
                                columns.RelativeColumn(1.1f); // Completed/Approved
                                columns.RelativeColumn(0.8f); // Rejected
                                columns.RelativeColumn(0.8f); // Active
                                columns.RelativeColumn(0.8f); // Inactive
                            });

                            table.Header(header =>
                            {
                                foreach (var title in new[] { "Description", "Total", "Pending", "Completed /\nApproved", "Rejected", "Active", "Inactive" })
                                    header.Cell().Background("#f1f5f9").Border(0.5f).BorderColor("#d1d5db").Padding(6).AlignCenter().Text(title).Bold().FontSize(8).FontColor("#374151");
                            });

                            void AddRow(string description, string total, string pending, string completed, string rejected, string active, string inactive)
                            {
                                table.Cell().Border(0.5f).BorderColor("#e5e7eb").Padding(6).Text(description).FontSize(9).FontColor("#374151");
                                table.Cell().Border(0.5f).BorderColor("#e5e7eb").Padding(6).AlignCenter().Text(total).FontSize(9);
                                table.Cell().Border(0.5f).BorderColor("#e5e7eb").Padding(6).AlignCenter().Text(pending).FontSize(9);
                                table.Cell().Border(0.5f).BorderColor("#e5e7eb").Padding(6).AlignCenter().Text(completed).FontSize(9);
                                // Rejected column — red color agar value > 0
                                var rejectedInt = int.TryParse(rejected, out var r) ? r : 0;
                                table.Cell().Border(0.5f).BorderColor("#e5e7eb").Padding(6).AlignCenter()
                                    .Text(rejected).FontSize(9)
                                    .FontColor(rejectedInt > 0 ? "#dc2626" : "#374151");
                                table.Cell().Border(0.5f).BorderColor("#e5e7eb").Padding(6).AlignCenter().Text(active).FontSize(9);
                                table.Cell().Border(0.5f).BorderColor("#e5e7eb").Padding(6).AlignCenter().Text(inactive).FontSize(9);
                            }

                            AddRow("Demands",        $"{model.TodayDemand}",       $"{model.PendingDemand}",       $"{model.ApprovedDemand}",       $"{model.RejectedDemand}",       "-",                        "-");
                            AddRow("Purchase Orders",$"{model.TodayPO}",           $"{model.PendingPO}",           $"{model.ApprovedPO}",           $"{model.RejectedPO}",           "-",                        "-");
                            AddRow("DMR",            $"{model.TodayDMR}",          $"{model.PendingDMR}",          $"{model.ApprovedDMR}",          $"{model.RejectedDMR}",          "-",                        "-");
                            AddRow("Bill Payments",  $"{model.TodayBillPayment}",  $"{model.PendingBillPayment}",  $"{model.ApprovedBillPayment}",  $"{model.RejectedBillPayment}",  "-",                        "-");
                            AddRow("Users",          $"{model.ActiveUsers + model.InactiveUsers}", "-",              "-",                             "-",                             $"{model.ActiveUsers}",     $"{model.InactiveUsers}");
                        });
                    });

                    page.Footer().Row(row =>
                    {
                        row.RelativeItem().PaddingTop(4).LineHorizontal(0.5f).LineColor("#cbd5e1");
                        row.ConstantItem(160).AlignCenter().Text("HMPK Daily Insight • System Generated Report").FontColor(Colors.Grey.Darken1).FontSize(8);
                        row.RelativeItem().PaddingTop(4).LineHorizontal(0.5f).LineColor("#cbd5e1");
                    });
                });

                // =====================================================================
                // PAGE 3: FLAG 2 AUDIT CONTROLS (RS1, RS2, RS3 METRICS)
                // =====================================================================
                if (model.Flag2PaymentSummaries.Any() || model.DiscountAlerts.Any() || model.StaffStudentAlerts.Any())
                {
                    container.Page(page =>
                    {
                        page.Size(PageSizes.A4);
                        page.Margin(20);
                        page.DefaultTextStyle(x => x.FontSize(9).FontColor(Colors.Black).FontFamily("Helvetica"));

                    page.Header().PaddingBottom(10).Column(column =>
                    {
                        column.Item().Text("FLAG 2: Audit Controls & Escalation Governance").Bold().FontSize(16).FontColor("#0b5fff");
                        column.Item().Text("Financial concessions tracking and administrative exceptions report").FontSize(9).FontColor(Colors.Grey.Darken2);
                        column.Item().PaddingTop(4).LineHorizontal(1f).LineColor("#d9e6ff");
                    });

                    page.Content().Column(column =>
                    {
                        column.Spacing(14);

                        // --- RS 1: Department Payment Audit Summary ---
                        column.Item().Text("Result Set 1: Department HOD Financial Remittance Summary").Bold().FontSize(10).FontColor(Colors.Grey.Darken3);
                        column.Item().Table(table =>
                        {
                            table.ColumnsDefinition(columns =>
                            {
                                columns.RelativeColumn(2.0f); columns.RelativeColumn(2.0f); columns.RelativeColumn(1.0f); columns.RelativeColumn(1.0f); columns.RelativeColumn(1.2f);
                            });

                            table.Header(header =>
                            {
                                string[] headers = { "Department", "HOD Name", "Cash Remitted", "Online Remitted", "Total Settlement" };
                                foreach (var h in headers)
                                {
                                    var cell = header.Cell().Background("#f1f5f9").Border(0.5f).BorderColor("#cbd5e1").Padding(4);
                                    if (h == "Department" || h == "HOD Name")
                                        cell.AlignLeft().Text(h).Bold().FontColor(Colors.Grey.Darken4).FontSize(8);
                                    else
                                        cell.AlignRight().Text(h).Bold().FontColor(Colors.Grey.Darken4).FontSize(8);
                                }
                            });

                            if (model.Flag2PaymentSummaries != null && model.Flag2PaymentSummaries.Any())
                            {
                                foreach (var item in model.Flag2PaymentSummaries)
                                {
                                    table.Cell().Border(0.5f).BorderColor("#e2e8f0").Padding(4).AlignLeft().Text(item.Department).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e2e8f0").Padding(4).AlignLeft().Text(item.HodName).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e2e8f0").Padding(4).AlignRight().Text(FormatCurrency(item.CashPaid, currencyCulture)).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e2e8f0").Padding(4).AlignRight().Text(FormatCurrency(item.OnlinePaid, currencyCulture)).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#e2e8f0").Padding(4).AlignRight().Text(FormatCurrency(item.TotalPaid, currencyCulture)).FontSize(8).Bold();
                                }
                            }
                            else
                            {
                                table.Cell().ColumnSpan(5).Border(0.5f).BorderColor("#e2e8f0").Padding(8).AlignCenter().Text("No Department Payment Overviews Logged").FontColor(Colors.Grey.Darken1).Italic();
                            }
                        });

                        // --- RS 2: General Patient Discount Alert ---
                        column.Item().Text("Result Set 2: Authorized Concessions & Discount Audit Trail").Bold().FontSize(10).FontColor("#b45309");
                        column.Item().Table(table =>
                        {
                            table.ColumnsDefinition(columns =>
                            {
                                columns.RelativeColumn(1.0f); columns.RelativeColumn(1.5f); columns.RelativeColumn(1.5f); columns.RelativeColumn(1.0f); columns.RelativeColumn(1.0f); columns.RelativeColumn(1.0f); columns.RelativeColumn(1.5f);
                            });
                            table.Header(header =>
                            {
                                string[] headers = { "UHID", "Patient Name", "Department", "Gross Amt", "Discount", "Net Paid", "Approved By" };
                                foreach (var h in headers)
                                {
                                    var cell = header.Cell().Background("#fff7ed").Border(0.5f).BorderColor("#fed7aa").Padding(4);
                                    if (h == "Gross Amt" || h == "Discount" || h == "Net Paid")
                                        cell.AlignRight().Text(h).Bold().FontColor("#c2410c").FontSize(8);
                                    else
                                        cell.AlignLeft().Text(h).Bold().FontColor("#c2410c").FontSize(8);
                                }
                            });
                            if (model.DiscountAlerts != null && model.DiscountAlerts.Any())
                            {
                                foreach (var item in model.DiscountAlerts)
                                {
                                    table.Cell().Border(0.5f).BorderColor("#ffedd5").Padding(4).AlignLeft().Text(item.UHID ?? "-").FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#ffedd5").Padding(4).AlignLeft().Text(item.PatientName ?? "-").FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#ffedd5").Padding(4).AlignLeft().Text(item.DepartmentName ?? "-").FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#ffedd5").Padding(4).AlignRight().Text(FormatCurrency(item.Amount, currencyCulture)).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#ffedd5").Padding(4).AlignRight().Text(FormatCurrency(item.Discount, currencyCulture)).FontSize(8).Bold().FontColor("#c2410c");
                                    table.Cell().Border(0.5f).BorderColor("#ffedd5").Padding(4).AlignRight().Text(FormatCurrency(item.PaidAmount, currencyCulture)).FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#ffedd5").Padding(4).AlignLeft().Text(item.ApprovedBy ?? "System Auto").FontSize(8);
                                }
                            }
                            else
                            {
                                table.Cell().ColumnSpan(7).Border(0.5f).BorderColor("#ffedd5").Padding(8).AlignCenter().Text("Zero Discount Exceptions Processed Today").FontColor(Colors.Grey.Darken1).Italic();
                            }
                        });
                        // --- RS 3: Staff / Student Exception Alert ---
                        column.Item().Text("Result Set 3: Institutional Subsidy Waivers (Staff & Student Exemptions)").Bold().FontSize(10).FontColor("#047857");
                        column.Item().Table(table =>
                        {
                            table.ColumnsDefinition(columns =>
                            {
                                columns.RelativeColumn(1.0f); columns.RelativeColumn(1.8f); columns.RelativeColumn(1.5f); columns.RelativeColumn(1.2f); columns.RelativeColumn(1.2f);
                            });
                            table.Header(header =>
                            {
                                string[] headers = { "UHID", "Beneficiary Name", "Department Module", "Institutional Class", "Actual Remittance" };
                                foreach (var h in headers)
                                {
                                    var cell = header.Cell().Background("#ecfdf5").Border(0.5f).BorderColor("#a7f3d0").Padding(4);
                                    if (h == "Actual Remittance")
                                        cell.AlignRight().Text(h).Bold().FontColor("#065f46").FontSize(8);
                                    else
                                        cell.AlignLeft().Text(h).Bold().FontColor("#065f46").FontSize(8);
                                }
                            });
                            if (model.StaffStudentAlerts != null && model.StaffStudentAlerts.Any())
                            {
                                foreach (var item in model.StaffStudentAlerts)
                                {
                                    table.Cell().Border(0.5f).BorderColor("#d1fae5").Padding(4).AlignLeft().Text(item.UHID ?? "-").FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#d1fae5").Padding(4).AlignLeft().Text(item.PatientName ?? "-").FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#d1fae5").Padding(4).AlignLeft().Text(item.DepartmentName ?? "-").FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#d1fae5").Padding(4).AlignLeft().Text(item.PatientType ?? "Staff/Student").FontSize(8).Bold();
                                    table.Cell().Border(0.5f).BorderColor("#d1fae5").Padding(4).AlignRight().Text(FormatCurrency(item.PaidAmount, currencyCulture)).FontSize(8);
                                }
                            }
                            else
                            {
                                table.Cell().ColumnSpan(5).Border(0.5f).BorderColor("#d1fae5").Padding(8).AlignCenter().Text("No Institutional Classification Discounts Claimed").FontColor(Colors.Grey.Darken1).Italic();
                            }
                        });
                    });

                        page.Footer().Row(row =>
                        {
                            row.RelativeItem().PaddingTop(4).LineHorizontal(0.5f).LineColor("#d9e6ff");
                            row.ConstantItem(120).AlignCenter().Text("Audit Verification Trail").FontColor(Colors.Grey.Darken1).FontSize(8);
                            row.RelativeItem().PaddingTop(4).LineHorizontal(0.5f).LineColor("#d9e6ff");
                        });
                    });
                }

                // =====================================================================
                // PAGE 4: FLAG 3 AGGREGATE PATIENT DAILY ROSTER
                // =====================================================================
                if (model.TodayPatients.Any())
                {
                    container.Page(page =>
                    {
                        page.Size(PageSizes.A4);
                        page.Margin(20);
                        page.DefaultTextStyle(x => x.FontSize(9).FontColor(Colors.Black).FontFamily("Helvetica"));

                    page.Header().PaddingBottom(10).Column(column =>
                    {
                        column.Item().Text("FLAG 3: Master Roster - Comprehensive Daily Patient Intake").Bold().FontSize(16).FontColor("#0b5fff");
                        column.Item().Text("Complete listing of patient visits, demographic status, and operational reception desks").FontSize(9).FontColor(Colors.Grey.Darken2);
                        column.Item().PaddingTop(4).LineHorizontal(1f).LineColor("#d9e6ff");
                    });

                    page.Content().Column(column =>
                    {
                        column.Item().Table(table =>
                        {
                            table.ColumnsDefinition(columns =>
                            {
                                columns.RelativeColumn(0.9f); columns.RelativeColumn(1.5f); columns.ConstantColumn(35); columns.RelativeColumn(1.0f); columns.RelativeColumn(1.5f); columns.RelativeColumn(0.9f); columns.ConstantColumn(45); columns.RelativeColumn(1.2f); columns.RelativeColumn(1.1f);
                            });

                            table.Header(header =>
                            {
                                string[] headers = { "UHID", "Patient Name", "Sex", "Mobile Num", "Assigned Unit", "Type", "Status", "Registered By", "Visit Roster" };
                                foreach (var h in headers)
                                {
                                    header.Cell().Background("#e8f1ff").Border(0.5f).BorderColor("#d6e7ff").Padding(4).AlignLeft().Text(h).Bold().FontColor("#0b5fff").FontSize(8);
                                }
                            });

                            if (model.TodayPatients != null && model.TodayPatients.Any())
                            {
                                foreach (var patient in model.TodayPatients)
                                {
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(3).AlignLeft().Text(patient.UHID ?? "-").FontSize(7);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(3).AlignLeft().Text(patient.Name ?? "-").FontSize(7).Bold();
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(3).AlignLeft().Text(patient.Gender ?? "-").FontSize(7);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(3).AlignLeft().Text(patient.Mobile ?? "-").FontSize(7);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(3).AlignLeft().Text(patient.Department ?? "-").FontSize(7);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(3).AlignLeft().Text(patient.PatientType ?? "General").FontSize(7);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(3).AlignLeft().Text(patient.NewOld ?? "-").FontSize(7);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(3).AlignLeft().Text(patient.RegisteredBy ?? "Desk System").FontSize(7);
                                    table.Cell().Border(0.5f).BorderColor("#e9eff8").Padding(3).AlignLeft().Text(patient.VisitDate == DateTime.MinValue ? DateTime.Now.ToString("dd-MMM") : patient.VisitDate.ToString("dd-MMM-yyyy")).FontSize(7);
                                }
                            }
                            else
                            {
                                table.Cell().ColumnSpan(9).Border(0.5f).BorderColor("#e9eff8").Padding(12).AlignCenter().Text("Zero Patient Intake Registered for the Day").FontColor(Colors.Grey.Darken1).Italic();
                            }
                        });
                    });

                        page.Footer().Row(row =>
                        {
                            row.RelativeItem().PaddingTop(4).LineHorizontal(0.5f).LineColor("#d9e6ff");
                            row.ConstantItem(120).AlignCenter().Text("Master Traffic Log").FontColor(Colors.Grey.Darken1).FontSize(8);
                            row.RelativeItem().PaddingTop(4).LineHorizontal(0.5f).LineColor("#d9e6ff");
                        });
                    });
                }

                // =====================================================================
                // DYNAMIC SEGMENT: FLAG 4 HOD LEVEL SPECIFIC PATIENT LEDGERS
                // =====================================================================
                if (model.Flag4HodPatients != null && model.Flag4HodPatients.Any())
                {
                    var groupedByHod = model.Flag4HodPatients.GroupBy(x => new { x.HodName, x.Department, x.HodEmail });

                    foreach (var group in groupedByHod)
                    {
                        container.Page(page =>
                        {
                            page.Size(PageSizes.A4);
                            page.Margin(20);
                            page.DefaultTextStyle(x => x.FontSize(9).FontColor(Colors.Black).FontFamily("Helvetica"));

                            page.Header().PaddingBottom(10).Column(column =>
                            {
                                column.Item().Row(row =>
                                {
                                    row.RelativeItem().Column(col =>
                                    {
                                        col.Item().Text($"FLAG 4: Specialist Clinical Log - {group.Key.Department}").Bold().FontSize(14).FontColor("#1e3a8a");
                                        col.Item().PaddingTop(2).Row(r =>
                                        {
                                            r.ConstantItem(180).Text($"Chief/HOD: {group.Key.HodName}").Bold().FontSize(9).FontColor(Colors.Grey.Darken3);
                                            r.RelativeItem().Text($"Direct Mail Routing: {group.Key.HodEmail}").FontSize(8).FontColor(Colors.Grey.Darken1).Italic();
                                        });
                                    });
                                });
                                column.Item().PaddingTop(4).LineHorizontal(1f).LineColor("#1e3a8a");
                            });

                            page.Content().Column(column =>
                            {
                                column.Spacing(8);
                                column.Item().Text($"The following patients were assigned to internal clinical pathways within the department of {group.Key.Department} under the governance of HOD {group.Key.HodName}.").FontSize(8).FontColor(Colors.Grey.Darken2);

                                column.Item().Table(table =>
                                {
                                    table.ColumnsDefinition(columns =>
                                    {
                                        columns.RelativeColumn(1.0f); columns.RelativeColumn(1.8f); columns.ConstantColumn(40); columns.RelativeColumn(1.2f); columns.RelativeColumn(2.5f); columns.RelativeColumn(1.2f);
                                    });

                                    table.Header(header =>
                                    {
                                        string[] headers = { "Patient UHID", "Patient Name", "Gender", "Contact Mobile", "Clinical Procedure", "Total Cost" };
                                        foreach (var h in headers)
                                        {
                                            var cell = header.Cell().Background("#eff6ff").Border(0.5f).BorderColor("#bfdbfe").Padding(4);
                                            if (h == "Total Cost")
                                                cell.AlignRight().Text(h).Bold().FontColor("#1e40af").FontSize(8);
                                            else
                                                cell.AlignLeft().Text(h).Bold().FontColor("#1e40af").FontSize(8);
                                        }
                                    });

                                    decimal departmentTotalGross = 0m;
                                    foreach (var patient in group)
                                    {
                                        table.Cell().Border(0.5f).BorderColor("#dbeafe").Padding(4).AlignLeft().Text(patient.UHID).FontSize(8);
                                        table.Cell().Border(0.5f).BorderColor("#dbeafe").Padding(4).AlignLeft().Text(patient.PatientName).FontSize(8).Bold();
                                        table.Cell().Border(0.5f).BorderColor("#dbeafe").Padding(4).AlignLeft().Text(patient.Gender).FontSize(8);
                                        table.Cell().Border(0.5f).BorderColor("#dbeafe").Padding(4).AlignLeft().Text(patient.Mobile).FontSize(8);
                                        table.Cell().Border(0.5f).BorderColor("#dbeafe").Padding(4).AlignLeft().Text(!string.IsNullOrWhiteSpace(patient.TreatmentGiven) ? patient.TreatmentGiven : "Observation / Active Checkup").FontSize(8);
                                        table.Cell().Border(0.5f).BorderColor("#dbeafe").Padding(4).AlignRight().Text(FormatCurrency(patient.GrossAmount, currencyCulture)).FontSize(8);

                                        departmentTotalGross += patient.GrossAmount;
                                    }

                                    // Total row for the HOD segment
                                    table.Cell().ColumnSpan(5).Border(0.5f).BorderColor("#dbeafe").Background("#f8fafc").Padding(4).AlignRight().Text("Department Total Summary:").Bold().FontSize(8);
                                    table.Cell().Border(0.5f).BorderColor("#dbeafe").Background("#f8fafc").Padding(4).AlignRight().Text(FormatCurrency(departmentTotalGross, currencyCulture)).Bold().FontSize(8).FontColor("#1e40af");
                                });
                            });

                            page.Footer().Row(row =>
                            {
                                row.RelativeItem().PaddingTop(4).LineHorizontal(0.5f).LineColor("#bfdbfe");
                                row.ConstantItem(150).AlignCenter().Text($"Flag 4 • {group.Key.Department} Ledger").FontColor(Colors.Grey.Darken1).FontSize(8);
                                row.RelativeItem().PaddingTop(4).LineHorizontal(0.5f).LineColor("#bfdbfe");
                            });
                        });
                    }
                }
            }).GeneratePdf(); // <--- Chain executed properly here to emit byte[] output
        }

        // =====================================================================
        // UTILITY HELPERS DEFINITION
        // =====================================================================
        private void CreateSummaryCard(ColumnDescriptor column, string title, string value, string description, string icon, string accentColor, string iconBackground = "#e2e8f0", string? iconPath = null)
        {
            column.Item().Row(r =>
            {
                r.RelativeItem().Text(title).Bold().FontSize(8).FontColor(Colors.Grey.Darken1);
                if (!string.IsNullOrWhiteSpace(iconPath) && File.Exists(iconPath))
                    r.ConstantItem(22).Height(22).Image(iconPath).FitArea();
                else if (!string.IsNullOrWhiteSpace(icon))
                    r.ConstantItem(22).Height(22).AlignCenter().AlignMiddle().Text(icon).Bold().FontSize(12).FontColor(accentColor);
            });
            column.Item().PaddingTop(2).Text(value).Bold().FontSize(12).FontColor(accentColor);
            column.Item().PaddingTop(1).Text(description).FontSize(7).FontColor(Colors.Grey.Darken2);
        }

        private void CreateOverallRevenueCard(ColumnDescriptor column, decimal created, decimal collected, CultureInfo culture, string? iconPath)
        {
            column.Item().Row(row =>
            {
                row.RelativeItem().Text("OVERALL REVENUE").Bold().FontSize(8).FontColor(Colors.Grey.Darken1);
                if (!string.IsNullOrWhiteSpace(iconPath) && File.Exists(iconPath))
                    row.ConstantItem(22).Height(22).Image(iconPath).FitArea();
            });

            column.Item().PaddingTop(3).Row(row =>
            {
                row.RelativeItem().Column(item =>
                {
                    item.Item().Text("CREATED").Bold().FontSize(7).FontColor("#7c3aed");
                    item.Item().PaddingTop(1).Text(FormatCurrency(created, culture)).Bold().FontSize(11).FontColor("#6d28d9");
                });
                row.RelativeItem().Column(item =>
                {
                    item.Item().Text("COLLECTED").Bold().FontSize(7).FontColor("#7c3aed");
                    item.Item().PaddingTop(1).Text(FormatCurrency(collected, culture)).Bold().FontSize(11).FontColor("#6d28d9");
                });
            });
        }

        private string FormatCurrency(decimal amount, CultureInfo culture)
        {
            return amount.ToString("C0", culture);
        }

        private string ResolveLogoPath()
        {
            return ResolveAssetPath("logo.png");
        }

        private string ResolveAssetPath(params string[] assetSegments)
        {
            return Path.Combine(_webHostEnvironment.WebRootPath, "Assets", Path.Combine(assetSegments));
        }
    }
}
